package it.corso.GestioneStudenti;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe per la gestione dei voti degli studenti.
 */
public class StudentGrades {

	private String studentName;
	private int grade;
	
	private Map<String, Integer> map;

	/**
     * Costruttore di default per la classe StudentGrades.
     * Inizializza la mappa dei voti degli studenti.
     */
	public StudentGrades() {
		this.studentName = studentName;
		this.grade = grade;
		this.map = new HashMap<>();
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}

	@Override
	public String toString() {
		return "StudentGrades [studentName=" + studentName + ", grade=" + grade + ", map=" + map + "]";
	}
	
	
	
	/**
     * Aggiunge un voto per lo studente specificato.
     * @param studentName Il nome dello studente.
     * @param grade Il voto dello studente.
     */
	 public void addGrade(String studentName, int grade) {
	        try {
	            if (grade < 0 || grade > 100) {
	                throw new Exception("Il voto deve essere compreso tra 0 e 100.");
	            }else
	            map.put(studentName, grade);
	        } catch (Exception e) {
	            System.out.println("Errore: " + e.getMessage());
	        }
	    }

	 
	 


	 /**
	  * Restituisce il voto dello studente specificato.
	  * @param studentName Il nome dello studente.
	  * @return Il voto dello studente. Se lo studente non è presente nella mappa, restituisce -1.
	  */
	 public int getGrade(String studentName) {
		 try {
			 if(map.containsKey(studentName)) {
				 return map.get(studentName);
			 }else 
				 throw new Exception("Lo studente non esiste.");
			 
		 } catch (Exception e) {
	            System.out.println("Errore: " + e.getMessage());
		 }
		return -1;
	 }
	
	 //return map.getOrDefault(studentName, -1);  ho cercato sulla documentazione perché mi sembrava troppo farraginoso il mio metodo e con una sola riga di questo ottengo lo stesso risultato,lascio comunque la mia implementazione di base
	 
	 
	 /**
	  * Stampa tutti i voti degli studenti presenti nella mappa.
	  */
	 public void printGrades() {
	        System.out.println("Voti degli studenti:");
	        map.forEach((studentName, grade) -> System.out.println(studentName + ": " + grade));
	    }
}
