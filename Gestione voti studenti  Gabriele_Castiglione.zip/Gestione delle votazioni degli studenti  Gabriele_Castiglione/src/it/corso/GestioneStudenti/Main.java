package it.corso.GestioneStudenti;

public class Main {

	public static void main(String[] args) {

		StudentGrades student = new StudentGrades();
		
		student.addGrade("Gabriele", 80);
		student.addGrade("Mario", 85);
		
		
		System.out.println(student.getGrade("Gabriele"));
		
		student.printGrades();
		
	}

}
