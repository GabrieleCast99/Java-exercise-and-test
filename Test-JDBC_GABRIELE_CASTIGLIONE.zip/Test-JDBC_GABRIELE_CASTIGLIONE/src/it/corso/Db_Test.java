package it.corso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.MysqlDataSource;

public class Db_Test {

	private Connection con;
	private String dbName;
	
	public Db_Test(String dbName) {
        this.dbName = dbName;
    }

	
	private Connection startConnection(String dbName) throws SQLException {
	    MysqlDataSource dataSource = new MysqlDataSource();
	    dataSource.setServerName("127.0.0.1");
	    dataSource.setPortNumber(3306);
	    dataSource.setUser("root");
	    dataSource.setPassword("Gabriele123_!");
	    dataSource.setDatabaseName(dbName); 
	    
	    return dataSource.getConnection();
	}

	
	
	public void createDatabase(String dbName) throws SQLException {
	    String createDbSql = "CREATE DATABASE IF NOT EXISTS " + dbName;
	    String useDbSql = "USE " + dbName;
	    
	    try (Connection con = startConnection(dbName)) { // Connettersi al database mysql per eseguire la creazione del database
	        PreparedStatement createDbStatement = con.prepareStatement(createDbSql);
	        createDbStatement.executeUpdate();
	        System.out.println("Database creato con successo.");
	        
	        PreparedStatement useDbStatement = con.prepareStatement(useDbSql);
	        useDbStatement.executeUpdate();
	        System.out.println("Database utilizzato con successo.");
	    }
	}

    
	
	
	public void createTable(String TableName) throws SQLException {
	    String sql = "CREATE TABLE IF NOT EXISTS "+TableName+ " (\r\n"
	               + "    ID INT PRIMARY KEY ,\r\n"
	               + "    Titolo VARCHAR(255),\r\n"
	               + "    autore VARCHAR(255)\r\n"
	               + "); ";
	    
	    try (Connection con = startConnection(dbName)) {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeUpdate(); 
	        System.out.println("Tabella,se non esistente, creata con successo.");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
    
	
	
	public void Insert(String Tabella,int id,String Titolo,String autore) throws SQLException {
	    String sql = "INSERT INTO "+Tabella+"(id,Titolo,autore) VALUES ('"+id+"','"+Titolo+"','"+autore+"')";
	    
	    try (Connection con = startConnection(dbName)) {
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeUpdate(); 
	        System.out.println("Insert creata con successo.");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	
	
	public void Select1() throws SQLException {
		String sql = "SELECT p.ID,l.Titolo, l.autore\r\n"
				+ "FROM prestito p\r\n"
				+ "INNER JOIN libro l ON p.FK_L = l.id\r\n"
				+ "WHERE FK_U = 4\r\n"
				+ "ORDER BY p.Data_inizio ASC;";
	    
	    try (Connection con = startConnection(dbName)) {
	    	
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeQuery();
	        
	        ResultSet rs = ps.executeQuery();
	        
	        while(rs.next()) {
	        	System.out.println("------------");
				System.out.println("id: "+ rs.getInt(1));
				System.out.println("Titolo: "+ rs.getString(2));
				System.out.println("Autore: "+ rs.getString(3));
				System.out.println("------------");
			}

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	
	public void Select2() throws SQLException {
		String sql = "SELECT  u.idUtente,u.nome, COUNT(*) AS numero_prestiti\r\n"
				+ "FROM prestito p\r\n"
				+ "INNER JOIN utente u ON p.FK_U = u.idUtente\r\n"
				+ "GROUP BY u.nome, u.idUtente\r\n"
				+ "LIMIT 3;";
	    
	    try (Connection con = startConnection(dbName)) {
	    	
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeQuery();
	        
	        ResultSet rs = ps.executeQuery();
	        
	        while(rs.next()) {
	        	System.out.println("------------");
				System.out.println("id: "+ rs.getInt(1));
				System.out.println("Nome: "+ rs.getString(2));
				System.out.println("numero prestiti: "+ rs.getString(3));
				System.out.println("------------");
			}

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	
	public void Select3() throws SQLException {
		String sql = "SELECT u.nome,l.Titolo\r\n"
				+ "FROM prestito p\r\n"
				+ "INNER JOIN libro l ON p.FK_L = l.id\r\n"
				+ "INNER JOIN utente u ON p.FK_U = u.idUtente\r\n"
				+ "WHERE p.Data_fine> NOW()\r\n"
				+ "ORDER BY p.Data_fine ASC;";
	    
	    try (Connection con = startConnection(dbName)) {
	    	
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeQuery();
	        
	        ResultSet rs = ps.executeQuery();
	        
	        while(rs.next()) {
	        	System.out.println("------------");
				System.out.println("Nome: "+ rs.getString(1));
				System.out.println("Titolo: "+ rs.getString(2));
				System.out.println("------------");
			}

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	public void Select4(int id) throws SQLException {
		String sql = "SELECT u.nome, l.Titolo\r\n"
				+ "FROM prestito p\r\n"
				+ "INNER JOIN libro l ON p.FK_L = l.id\r\n"
				+ "INNER JOIN utente u ON p.FK_U = u.idUtente\r\n"
				+ "WHERE u.idUtente = " +id+ "\r\n"
				+ "AND p.Data_inizio >= '2024-01-01'\r\n"
				+ "AND p.Data_fine <= '2024-12-31';";
	    
	    try (Connection con = startConnection(dbName)) {
	    	
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeQuery();
	        
	        ResultSet rs = ps.executeQuery();
	        
	        while(rs.next()) {
	        	System.out.println("------------");
				System.out.println("Nome: "+ rs.getString(1));
				System.out.println("Titolo: "+ rs.getString(2));
				System.out.println("------------");
			}

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	
	public void Select5() throws SQLException {
		String sql = "SELECT p.id,u.nome, l.Titolo\r\n"
				+ "FROM prestito p\r\n"
				+ "INNER JOIN libro l ON p.FK_L = l.id\r\n"
				+ "INNER JOIN utente u ON p.FK_U = u.idUtente\r\n"
				+ "WHERE DATEDIFF(p.Data_fine, p.Data_inizio) > 15;";
	    
	    try (Connection con = startConnection(dbName)) {
	    	
	        PreparedStatement ps = con.prepareStatement(sql);
	        ps.executeQuery();
	        
	        ResultSet rs = ps.executeQuery();
	        
	        while(rs.next()) {
	        	System.out.println("------------");
				System.out.println("id: "+ rs.getInt(1));
				System.out.println("Nome: "+ rs.getString(2));
				System.out.println("Titolo: "+ rs.getString(3));
				System.out.println("------------");
			}

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
}
