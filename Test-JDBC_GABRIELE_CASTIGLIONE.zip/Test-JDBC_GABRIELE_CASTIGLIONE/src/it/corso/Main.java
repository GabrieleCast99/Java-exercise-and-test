package it.corso;

import java.sql.SQLException;

public class Main {

	public static void main(String[] args) {
		String dbName = "Test_Db";
		String TableName = "libro";
		Db_Test test = new Db_Test(dbName);
		try {
			
			test.createDatabase(dbName);
			test.createTable(TableName);
			//test.Insert("libro",1,"Titolo1", "Autore1");
			
			
			System.out.println("Libri prestati a Vallieri");
			test.Select1();
			
			System.out.println("Primi 3 lettori che leggono piú libri");
			test.Select2();
			
			System.out.println("Libri da restituire");
			test.Select3();
			
			System.out.println("Libri da restituire per utente specifico in un range");
			test.Select4(1);
				
			System.out.println("Libri con una durata maggiore di 15gg");
			test.Select5();
			
			
			
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
