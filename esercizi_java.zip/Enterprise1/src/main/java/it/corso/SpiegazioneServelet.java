package it.corso;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class SpiegazioneServelet
 */
@WebServlet
public class SpiegazioneServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SpiegazioneServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//response.getWriter().append(" "+" il metodo é: "+ request.getMethod()).append(" "+request.getContextPath());
		/*	
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String euroParam = request.getParameter("euro");

        if (euroParam == null || euroParam.isEmpty()) {
            out.println("<p>Il parametro euro non è stato fornito o è vuoto.</p>");
            return;
        }

        double euro = Double.parseDouble(euroParam);
        double tassoCambio = 1.22; 

        double dollari = euro * tassoCambio;

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<body>");
        out.println("<h1>Conversione</h1>");
        out.println("<p>Importo in euro: " + euro + "</p>");
        out.println("<p>Importo in dollari: " + dollari + "</p>");
        out.println("</body>");
        out.println("</html>");
        
        */
		
		
		String pagina = request.getParameter("pagina");

        String nextPage;
        if (pagina.equals("1")) {
            nextPage = "/jsp/pagina1.jsp";
        } else if (pagina.equals("2")) {
            nextPage = "/jsp/pagina2.jsp";
        } else if (pagina.equals("3")) {
            nextPage = "/jsp/pagina3.jsp";
        } else {
            nextPage = "/jsp/pagina1.jsp";
        }

        RequestDispatcher dispatcher = request.getRequestDispatcher(nextPage);

        dispatcher.include(request, response);
    }
        
        
        
        
        
        
        
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
