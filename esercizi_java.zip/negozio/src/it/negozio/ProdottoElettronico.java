package it.negozio;

public class ProdottoElettronico extends Prodotto {

	private int scadenza;

	public ProdottoElettronico(String codiceUnico, String descrizione, int quantitá, double prezzo, int scadenza) {
		super(codiceUnico, descrizione, quantitá, prezzo);
		this.scadenza = scadenza;
	}

	public int getScadenza() {
		return scadenza;
	}

	public void setScadenza(int scadenza) {
		this.scadenza = scadenza;
	}
	
	@Override
	public String toString() {
		return "Prodotto [codiceUnico=" + getCodiceUnico() + ", descrizione=" + getDescrizione() + ", quantitá=" + getQuantitá()
				+ ", prezzo=" + getPrezzo() + ", Garanzia in mesi="+ scadenza+ "]";
	}
}
