package it.negozio;

import java.util.Date;

public class Main {

	public static void main(String[] args) {
		Negozio controlloScorte = new Negozio();

		Prodotto prodotto1= new Prodotto("BX123","Piatto",4,1.99);
		Date dataScadenza = new Date(2024, 4, 28);	//prova ad usare anche Calendar anziché Date	
		ProdottoAlimentare prodotto2= new ProdottoAlimentare("AX123","Pane",4,1.99,dataScadenza );
		
		System.out.println(controlloScorte.aggiungiProdotto(prodotto1));
		System.out.println(controlloScorte.aggiungiProdotto(prodotto2));

		System.out.println(controlloScorte.modificaQuantitá(6, "AX123"));

		
		controlloScorte.visualizzaLista();
		
		controlloScorte.eliminaProdotto("AX123");
		
		
	}

}
