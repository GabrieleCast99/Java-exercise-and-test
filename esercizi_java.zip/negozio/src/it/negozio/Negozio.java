package it.negozio;

import java.util.ArrayList;
import java.util.Iterator;

public class Negozio {
	
    private ArrayList<Prodotto> lista;

	public Negozio() {
		this.lista = new ArrayList<>();
	}

	public ArrayList<Prodotto> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Prodotto> lista) {
		this.lista = lista;
	}

	@Override
	public String toString() {
		return "controlloScorte [lista=" + lista + "]";
	}
    
    public Prodotto aggiungiProdotto(Prodotto prodotto) {
    	lista.add(prodotto);
    	return prodotto;
    }

    public boolean modificaQuantitá(int quantitá,String codice) {
    	for(Prodotto prodotto: lista) {
    		if(prodotto.getCodiceUnico().equals(codice)) {
    			prodotto.setQuantitá(quantitá);
    			return true;
    		}
    	}
		return false;
    }
    
    
    public void visualizzaLista() {
    	for(Prodotto prodotto: lista) {
    		System.out.println(prodotto);
    	}
		
    }
    
    public void eliminaProdotto(String codice) {
        Iterator<Prodotto> iterator = lista.iterator();
        while (iterator.hasNext()) {
            Prodotto prodotto = iterator.next();
            if (prodotto.getCodiceUnico().equals(codice)) {
                iterator.remove(); 
                System.out.println("Prodotto eliminato");
                break;
            }
        }
    }
    // boolean rimosso = prodotti.removeif( prodotto -> prodotto.getCe().equals(codice));
}
