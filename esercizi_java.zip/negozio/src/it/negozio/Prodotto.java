package it.negozio;

public class Prodotto {
	
	private String codiceUnico;
	private String descrizione;
	private int quantitá;
	private double prezzo;
	public Prodotto(String codiceUnico, String descrizione, int quantitá, double prezzo) {
		super();
		this.codiceUnico = codiceUnico;
		this.descrizione = descrizione;
		this.quantitá = quantitá;
		this.prezzo = prezzo;
	}
	public String getCodiceUnico() {
		return codiceUnico;
	}
	public void setCodiceUnico(String codiceUnico) {
		this.codiceUnico = codiceUnico;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public int getQuantitá() {
		return quantitá;
	}
	public void setQuantitá(int quantitá) {
		this.quantitá = quantitá;
	}
	public double getPrezzo() {
		return prezzo;
	}
	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}
	@Override
	public String toString() {
		return "Prodotto [codiceUnico=" + codiceUnico + ", descrizione=" + descrizione + ", quantitá=" + quantitá
				+ ", prezzo=" + prezzo + "]";
	}
	
	
	

}
