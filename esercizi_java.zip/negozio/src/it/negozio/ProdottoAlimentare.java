package it.negozio;

import java.util.Date;

public class ProdottoAlimentare extends Prodotto {

	private Date dataScadenza;

	public ProdottoAlimentare(String codiceUnico, String descrizione, int quantitá, double prezzo, Date dataScadenza) {
		super(codiceUnico, descrizione, quantitá, prezzo);
		this.dataScadenza = dataScadenza;
	}

	public Date getDataScadenza() {
		return dataScadenza;
	}

	public void setDataScadenza(Date dataScadenza) {
		this.dataScadenza = dataScadenza;
	}
	
	@Override
	public String toString() {
		return "Prodotto [codiceUnico=" + getCodiceUnico() + ", descrizione=" + getDescrizione() + ", quantitá=" + getQuantitá()
				+ ", prezzo=" + getPrezzo() + ", Data di scadenza="+ dataScadenza+ "]";
	}
}
