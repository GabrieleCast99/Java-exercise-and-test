package it.corso.Junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class MainTest {

	@Test
	void sonoPari() {
		
		int numeroPari= 10;
		
		int numeroPari2= 10;

		
		boolean risultato = Main.sonoPari(numeroPari,numeroPari2);
		
        assertTrue(risultato, "Entrambi i numeri sono pari");

	}
	
	@Test
	void sonoDispari() {
		
		int numeroPari= 9;
		
		int numeroPari2= 9;

		
		boolean risultato = Main.sonoPari(numeroPari,numeroPari2);
		
        assertFalse(risultato, "Entrambi i numeri sono dispari");

	}
	
	@Test
	void PrimoMaggiore() {
		
		int numeroPari= 10;
		
		int numeroPari2= 7;

		
		boolean risultato = Main.sonoPari(numeroPari,numeroPari2);
		
        assertTrue(risultato, "Primo Maggiore del secondo");

	}
	
	@Test
	void SecondoMaggiore() {
		
		int numeroPari= 7;
		
		int numeroPari2= 10;

		
		boolean risultato = Main.sonoPari(numeroPari,numeroPari2);
		
        assertFalse(risultato, "Secondo Maggiore del primo");

	}
}
