package it.corso.Junit;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("digitare un numero");
		int numero= scanner.nextInt();
		System.out.println("digitare un' altro numero");
		int numero2= scanner.nextInt();

		System.out.println(sonoPari(numero,numero2));
		
		
		scanner.close();
	}
	
	public static final boolean sonoPari(int numero,int numero2) {
        if( numero % 2 == 0 && numero2 % 2==0){
        	return true;
        }else if(numero % 2 != 0 && numero2 % 2 !=0) {
        	return false;
        }else if(numero>numero2) {
        	return true;
        }else
		return false;
    }

}
