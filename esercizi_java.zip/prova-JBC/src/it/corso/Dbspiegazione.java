package it.corso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.cj.jdbc.MysqlDataSource;

public class Dbspiegazione {
	//connessione al database specifico
	private Connection con;
	
	public static void main(String[] args) {
		Dbspiegazione prova = new Dbspiegazione();
		try {
			//System.out.println(prova.startConnection().isValid(100));
			//prova.esempioSelect();
			//prova.esempioUpdate();
			prova.esempioDelete();
			//prova.esempioInsert("Gabriele", "Castiglione", "ciao@ciao.it");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private Connection startConnection() throws SQLException {
		if(con == null) {
			MysqlDataSource dataSource = new MysqlDataSource();
			dataSource.setServerName("127.0.0.1");
			dataSource.setPortNumber(3306);
			dataSource.setUser("root");
			dataSource.setPassword("Gabriele123_!");
			dataSource.setDatabaseName("corso_java");
			
			con = dataSource.getConnection();


		}
		return con;
	}

	private void esempioSelect() throws SQLException {
		String sql = "SELECT * FROM utenti";
		
		PreparedStatement ps = startConnection().prepareStatement(sql);
		
		ResultSet rs = ps.executeQuery();
		
		while(rs.next()) {
			System.out.println("id: "+ rs.getInt(1));
			System.out.println("nome: "+ rs.getString(2));
			System.out.println("cognome: "+ rs.getString(3));
			System.out.println("email: "+ rs.getString(4));
			System.out.println("------------");
		}
	}
	
	
	private void esempioInsert(String nome, String cognome,String email) throws SQLException {
		String sql = "INSERT INTO utenti(nome,cognome,email) VALUES ('"+nome+"','"+cognome+"','"+email+"')";
		
		PreparedStatement ps = startConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS );
		ps.executeUpdate();
		ResultSet rs = ps.getGeneratedKeys();
		rs.next();
		System.out.println("id: "+ rs.getInt(1));
		

	}
	
	private void esempioUpdate() throws SQLException {
		String sql = "UPDATE utenti SET nome='luigi' WHERE ID = 1";
		
		PreparedStatement ps = startConnection().prepareStatement(sql);
		ps.executeUpdate();
		

	}
	
	private void esempioDelete() throws SQLException {
		String sql = "DELETE FROM utenti WHERE ID = 1";
		
		PreparedStatement ps = startConnection().prepareStatement(sql);
		ps.executeUpdate();
		

	}
	
}
