package it.input;

import java.io.*;

public class Main {

    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(System.getProperty("user.home") + "/Downloads/input.txt"));

            String line;
            int wordCount=0;
            System.out.println("Contenuto del file:");

            while ((line = reader.readLine()) != null) {
            	String[] words = line.split("\\s");
            	
            	wordCount+=words.length;
            	
            	System.out.println(line);
            	
                System.out.println(wordCount);
                
                line = line.replaceAll("\\s", "");
                
                System.out.println(line.length());
                
                double lunghezzaMedia= (double) line.length()/wordCount;
                
                System.out.println(lunghezzaMedia);
                
                
            }

            reader.close();
            
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
