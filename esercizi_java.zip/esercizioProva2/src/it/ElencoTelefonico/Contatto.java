package it.ElencoTelefonico;

import java.util.LinkedList;
/**
 * Classe con caratteristiche base per un contatto telefonico
 */

public class Contatto {
	/**
     * Il nome del contatto
     */
	private String nome;
	   /**
     * Il numero di telefono del contatto
     */
	private String numeroTelefono;
	 /**
     * L'etichetta associata al contatto 
     */
	private String etichetta;
	
	/**
     * Costruisce un nuovo oggetto Contatto con le informazioni specificate
     *
     * @param nome Il nome del contatto
     * @param numeroTelefono Il numero di telefono del contatto
     * @param etichetta L'etichetta associata al contatto
     */
	public Contatto(String nome, String numeroTelefono, String etichetta) {
		super();
		this.nome = nome;
		this.numeroTelefono = numeroTelefono;
		this.etichetta = etichetta;
	}

	 /**
     * Restituisce il nome del contatto
     *
     */
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}

	public String getEtichetta() {
		return etichetta;
	}

	public void setEtichetta(String etichetta) {
		this.etichetta = etichetta;
	}

	/**
     * Restituisce una stringa che rappresenta il contatto
     *
     */
	@Override
	public String toString() {
		return "Contatto [nome=" + nome + ", numeroTelefono=" + numeroTelefono + ", etichetta=" + etichetta + "]";
	}

	
}
