package it.ElencoTelefonico;

import java.util.LinkedList;

public class ContattoPersonale extends Contatto {

	

	private String indirizzoCasa;

	public ContattoPersonale(String nome, String numeroTelefono, String etichetta, String indirizzoCasa) {
		super(nome, numeroTelefono, etichetta);
		this.indirizzoCasa = indirizzoCasa;
	}

	public String getIndirizzoCasa() {
		return indirizzoCasa;
	}

	public void setIndirizzoCasa(String indirizzoCasa) {
		this.indirizzoCasa = indirizzoCasa;
	}

	
	
	@Override
	public String toString() {
		return "ContattoPersonale [nome=" + getNome() + ", numeroTelefono=" + getNumeroTelefono() + ", etichetta=" + getEtichetta() + ", indirizzoCasa= " + indirizzoCasa +"]";
	}
	
	
}
