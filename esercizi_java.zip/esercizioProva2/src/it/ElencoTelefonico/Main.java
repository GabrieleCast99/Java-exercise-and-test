package it.ElencoTelefonico;

import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {

		ElencoTelefonico elencoTelefonico = new ElencoTelefonico();

        
		
		Contatto contatto1= new Contatto("Gabriele", "389481", "Cellulare");
		Contatto contatto2= new Contatto("Gabriele", "3894812", "Fisso");

		
		elencoTelefonico.aggiungiContatto(contatto1);
		elencoTelefonico.aggiungiContatto(contatto2);

		
		elencoTelefonico.cercaNome("Gabriele");
		
		elencoTelefonico.eliminaContatto("389481");
		
		
		ContattoPersonale contatto3= new ContattoPersonale("Mario", "388765", "Cellulare", "Casa");
		
		elencoTelefonico.aggiungiContatto(contatto3);
	}

}
