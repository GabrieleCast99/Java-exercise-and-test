package it.ElencoTelefonico;

import java.util.LinkedList;

public class ElencoTelefonico {
    private LinkedList<Contatto> lista;

	public LinkedList<Contatto> getLista() {
		return lista;
	}

	public void setLista(LinkedList<Contatto> lista) {
		this.lista = lista;
	}

	public ElencoTelefonico() {
		this.lista = new LinkedList<>();
	}

	@Override
	public String toString() {
		return "ElencoTelefonico [lista=" + lista + "]";
	}
	
    
	/**
     * Aggiunge un nuovo contatto alla lista specificata e stampa un messaggio di conferma
     *
     * @param lista La lista in cui aggiungere il contatto
     * @param contatto Il contatto da aggiungere alla lista
     */
	 public void aggiungiContatto(Contatto contatto) {
	        lista.add(contatto);
		System.out.println("Aggiunto: "+contatto.toString());
	}
	
	 /**
     * Cerca un contatto nella lista specificata tramite il nome
     *
     * @param lista La lista in cui cercare il contatto
     * @param nome Il nome del contatto da cercare
     */
	public void cercaNome(String nome) {
		for(Contatto contatto: lista) {
			if(contatto.getNome().equalsIgnoreCase(nome)) {
				System.out.println("Contatto con questo nome trovato: "+ contatto.toString());
			}else {
				System.out.println("Nessuna Corrispondenza");
			}
		}
	}
	
	
	
	/**
     * Elimina un contatto dalla lista specificata tramite il numero di telefono specificato
     *
     * @param lista La lista da cui eliminare il contatto
     * @param numero Il numero di telefono del contatto da eliminare
     */
	public void eliminaContatto(String numero) {
		for(Contatto contatto: lista) {
			if(contatto.getNumeroTelefono().equals(numero)) {
				lista.remove(contatto);
				System.out.println("contatto eliminato");
			}
	
		}
	}

}
