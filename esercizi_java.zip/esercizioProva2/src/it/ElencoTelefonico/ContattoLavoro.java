package it.ElencoTelefonico;

import java.util.LinkedList;

public class ContattoLavoro extends Contatto {

	private String luogoLavoro;

	public ContattoLavoro(String nome, String numeroTelefono, String etichetta, String luogoLavoro) {
		super(nome, numeroTelefono, etichetta);
		this.luogoLavoro = luogoLavoro;
	}

	public String getLuogoLavoro() {
		return luogoLavoro;
	}

	public void setLuogoLavoro(String luogoLavoro) {
		this.luogoLavoro = luogoLavoro;
	}
	
	@Override
	public String toString() {
		return "ContattoPersonale [nome=" + getNome() + ", numeroTelefono=" + getNumeroTelefono() + ", etichetta=" + getEtichetta() + ", Luogo lavoro= " + luogoLavoro +"]";
	}

	
}
