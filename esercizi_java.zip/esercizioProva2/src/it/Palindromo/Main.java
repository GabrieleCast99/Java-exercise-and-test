package it.Palindromo;

public class Main {

	public static void main(String[] args) {
		Palindromo palindromo = new Palindromo();
		String s1= "anna";
		
        System.out.println("La stringa '" + s1 + "' è un palindromo? " + palindromo.Check(s1));
	}

}
