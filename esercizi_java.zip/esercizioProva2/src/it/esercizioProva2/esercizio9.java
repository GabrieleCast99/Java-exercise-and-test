package it.esercizioProva2;

import java.util.Scanner;

public class esercizio9 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("digitare una password");
		
		boolean passCorrect=false; 
		
		while(passCorrect==false) {
		String password= scanner.nextLine();
		
		if(password.length()>=8){
			
			if(password.contains("@") || password.contains("$") ||password.contains("&")) {
				passCorrect=true;
			}else
				System.out.println("digitare una password corretta con almeno un segno @,$,&");
			}
		else
			System.out.println("digitare una password corretta con almeno 8 carateri");

		}
		
		scanner.close();
		System.out.println("Password accettata");
	}
	

}
