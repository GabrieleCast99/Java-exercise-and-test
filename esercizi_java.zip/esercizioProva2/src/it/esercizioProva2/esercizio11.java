package it.esercizioProva2;

import java.util.Scanner;

public class esercizio11 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("digitare un numero da 1 a 7");
		int numero= scanner.nextInt();
		
		if(numero>=1 || numero<=7) {
		
		
		String giornoSettimana = null;
		
		switch(numero) {
		case 1:
			giornoSettimana="lunedi";
			break;
		case 2:
			giornoSettimana="martedi";
			break;
		case 3:
			giornoSettimana="mercoledi";
			break;
		case 4:
			giornoSettimana="giovedi";
			break;
		case 5:
			giornoSettimana="vener";
			break;
		case 6:
			giornoSettimana="sabato";
			break;
		case 7:
			giornoSettimana="domenica";
			break;	
		
		}
		
		System.out.println("Il numero selezionato corrisponde a: "+ giornoSettimana);
		scanner.close();
		
		}else
			System.out.println("Il numero non é valido");

		
		
	}


}
