package it.esercizioProva2;

import java.util.Scanner;

public class esercizio10 {

	public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("Inserisci valore a");
        double a= input.nextDouble();
        
        System.out.println("Inserisci valore b");
        double b= input.nextDouble();
        
        System.out.println("Inserisci valore c");
        double c= input.nextDouble();
        
        double discriminante = (b*b) - (4*a*c) ;
        
        if(discriminante>0) {
        	double x1 = (-b + Math.sqrt(discriminante)) / (2 * a);
        	double x2 = (-b - Math.sqrt(discriminante)) / (2 * a);
            System.out.println("Due radici reali e distinte: "+x1+" e "+x2);
        }else if(discriminante==0) {
        	double x3 = (-b )/ (2 * a);
            System.out.println("Due radici uguali: "+x3);
        }else 
        	System.out.println("Nessuna soluzione reale");
        
        
        input.close();
	}

}
