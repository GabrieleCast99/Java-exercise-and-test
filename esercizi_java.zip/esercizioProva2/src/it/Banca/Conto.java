package it.Banca;

public class Conto {

	private int conto;

	public Conto(int conto) {
		this.conto = conto;
	}

	public int getConto() {
		return conto;
	}

	public void setConto(int conto) {
		this.conto = conto;
	}

	@Override
	public String toString() {
		return "Conto [conto=" + conto + "]";
	}
	

	public void deposito(double importo) {
        conto += importo;
        System.out.println("Aggiunti " + importo + " euro al saldo.");
    }
	
	public void sottrazione(int importo) {
		if(importo<conto) {
		conto-=importo;
        System.out.println("Rimossi " + importo + " euro al saldo.");
		}else
	        System.out.println("Non sono presenti abbastana soldi");
	}
}
