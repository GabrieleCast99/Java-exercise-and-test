package it.Banca;

public class Main {

	public static void main(String[] args) {
		Conto conto = new Conto(0);
		
		
		conto.deposito(1000);
		
		conto.sottrazione(500);
		
		conto.sottrazione(400);
		
		conto.sottrazione(400);
		
		System.out.println(conto.getConto());
	}

}
