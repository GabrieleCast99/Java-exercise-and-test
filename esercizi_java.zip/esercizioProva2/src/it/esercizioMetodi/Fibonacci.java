package it.esercizioMetodi;

public class Fibonacci {
	/*
	 * Scrivere un metodo che calcola l’n-esimo numero di Fibonacci. Si ricorda  la definizione dei numeri di Fibonacci:
▶ fib(0) = 1,
▶ fib(1) = 1,
▶ fib(n) = fib(n−1)+fib(n−2) per n ≥ 2.
▶ Se al metodo viene passato un numero intero negativo il metodo restituisce -1
	 */
	
	
	public int fibonacci(int n) {
		if (n < 0) {
            return -1;
        }
        
        int a = 1;
        int b = 1;
        
        for (int i = 2; i <= n; i++) {
            int temp = a + b;
            a = b;
            b = temp;
        }
        
        return a;
    }
	
	
	
	

}
