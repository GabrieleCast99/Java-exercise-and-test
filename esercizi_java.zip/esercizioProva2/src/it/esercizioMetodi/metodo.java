package it.esercizioMetodi;

public class metodo {
	
	public boolean check(String s,char c) {
		
		String stringC= Character.toString(c);
		
		if(s.contains(stringC)) {
			return true;
		}
		
		return false;
	}	
	
	
	
	public int checkNumero(String s,char c) {
		int count=0;
		
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)==c) {
				count++;
			}
		}
		return count;
	}
	
	public boolean checkNumero2(String s,char c1,char c2) {
		int count1=0;
		int count2=0;

		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)==c1) {
				count1++;
			}
		}
		
		for(int i=0;i<s.length();i++) {
			if(s.charAt(i)==c2) {
				count2++;
			}
		}
		return count1==count2;
	}
	
	
	public int checkPosizione(String string,char c) {
		int count=-1;
		
		for(int i=0;i<string.length();i++) {
			if(string.charAt(i)==c) {
				count=i;
				return count;
			}
		}
		return count;
	}
	
	
	/*
	 * Scrivere un metodo che, dati una stringa (non vuota) s ed un carattere c,  
	 * restituisce una nuova stringa ottenuta da s inserendo c tra ogni carattere  di s ed il suo successore. 
	 * Esempio: se s = "alloro" e c = ’-’, il metodo  restituisce la stringa "a-l-l-o-r-o".
	 */
	
	
	//secondo esercizio
	public String checkRimpiazzo(String string,char c) {
		
		StringBuilder stringB = new StringBuilder();
		
		for(char cString : string.toCharArray()) {
			
			stringB.append(cString).append(c);
			
		}
		return stringB.toString();
	}
}
