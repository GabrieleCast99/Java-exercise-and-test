package it.esercizioMetodi;

public class Main {

	public static void main(String[] args) {
		metodo metodo=new metodo();
		Fibonacci fibonacci = new Fibonacci();
		char c= 'c';
		char c2= 'i';

		String s= "ciao";
		int n = 1;
		
		boolean risultato= metodo.check(s,c);
		System.out.println(risultato);
		
		int risultato2=metodo.checkNumero(s, c);
		System.out.println(risultato2);
	
		System.out.println("--------");
		
		boolean risultatoTest=metodo.checkNumero2(s, c, c2);
		System.out.println(risultatoTest);

		System.out.println("--------");
		int risultato3=metodo.checkPosizione(s, c);
		System.out.println(risultato3);
		
		String risultato4=metodo.checkRimpiazzo(s, c);
		System.out.println(risultato4);
		
		
		System.out.println("--------");

		int risultato5=fibonacci.fibonacci(n);
		System.out.println(risultato5);
	}
}
