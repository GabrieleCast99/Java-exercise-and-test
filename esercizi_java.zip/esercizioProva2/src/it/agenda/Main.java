package it.agenda;

public class Main {

	public static void main(String[] args) {

		Agenda agenda= new Agenda();
		
		 	agenda.getList().add("Fare la spesa");
	        agenda.getList().add("Studiare per l'academy");
	        agenda.getList().add("Chiamare il dentista");
	        
	        System.out.println("Lista: ");
	        
	        for(String list: agenda.getList()) {
	        	System.out.println(list);
	        }
	}

}
