package it.agenda;

import java.util.ArrayList;
import java.util.List;

public class Agenda {

	private List<String> list;
	
	
	public Agenda() {
        this.list = new ArrayList<>();
    }


	public List<String> getList() {
		return list;
	}


	
	
	
}
