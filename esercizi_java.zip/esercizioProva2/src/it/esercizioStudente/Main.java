package it.esercizioStudente;

public class Main {

	public static void main(String[] args) {
		studente studente1=new studente("Gabriele","Castiglione","ABCDEF");
		
		
		System.out.println(studente1.getNome());	
		System.out.println(studente1.getCognome());				
		System.out.println(studente1.getMatricola());		
		System.out.println(studente1);	
		
		studente1.setNome("Mario");
		studente1.setCognome("Rossi");
		System.out.println(studente1);		

		
		
		studente studente2=new studente("Verdi","ABCDEF");
		System.out.println(studente2.getInfoStudente());
		
	}

}
