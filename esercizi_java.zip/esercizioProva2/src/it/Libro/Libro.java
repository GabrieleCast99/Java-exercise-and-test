package it.Libro;

public class Libro {

	private String titolo;
	private String ISBN;
	private String nome_autore;
	private int year;
	
	
	
	public Libro(String titolo, String iSBN, String nome_autore, int year) {
		this.titolo = titolo;
		this.ISBN = iSBN;
		this.nome_autore = nome_autore;
		this.year = year;
	}



	public String getTitolo() {
		return titolo;
	}



	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}



	public String getISBN() {
		return ISBN;
	}



	public void setISBN(String iSBN) {
		this.ISBN = iSBN;
	}



	public String getNome_autore() {
		return nome_autore;
	}



	public void setNome_autore(String nome_autore) {
		this.nome_autore = nome_autore;
	}



	public int getYear() {
		return year;
	}



	public void setYear(int year) {
		this.year = year;
	}



	
	public void stampaInfo() {
		System.out.println("Libro [titolo=" + titolo + ", ISBN=" + ISBN + ", nome_autore=" + nome_autore + ", year=" + year + "]"); 
	}
	
	
	public String ottieniInfo() {
		return "Libro [titolo=" + titolo + "\nISBN=" + ISBN + "\nnome_autore=" + nome_autore + "\nyear=" + year + "]";
	}
	
	
}
