package it.Libro;

public class Main {

	public static void main(String[] args) {
		Libro libro = new Libro("Il signore degli anelli","AHB176VUTFD", "J. R. R. Tolkien", 1954);
		
		libro.stampaInfo();
		
		
		
		System.out.println(libro.ottieniInfo());
		
	}

}
