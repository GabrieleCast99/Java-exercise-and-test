package it.esercizioQuadrato;

public class Main {
/*
 * 	Creare una classe Quadrato, che dichiari una variabile d’istanza intera  lato.
 *  Quindi creare un metodo pubblico che si chiami perimetro() e che  ritorni il perimetro del quadrato,
 *  e un metodo pubblico area() che ritorni  l’area del quadrato.
 */
	public static void main(String[] args) {
		Quadrato quadrato1 = new Quadrato(5);
		
		
		int perimetro = quadrato1.Perimetro();
        int area = quadrato1.Area();

        System.out.println("Perimetro: " + perimetro);
        System.out.println("Area: " + area);
		
	}

}
