package it.esercizioQuadrato;
/*
 * 	Creare una classe Quadrato, che dichiari una variabile d’istanza intera  lato.
 *  Quindi creare un metodo pubblico che si chiami perimetro() e che  ritorni il perimetro del quadrato,
 *  e un metodo pubblico area() che ritorni  l’area del quadrato.
 */
public class Quadrato {

	private int lato;
	
	
	public Quadrato(int lato) {
		this.lato = lato;
	}
	
	
	public int getLato() {
		return lato;
	}
	public void setLato(int lato) {
		this.lato = lato;
	}
	
	
	
	
	
	public int Perimetro() {
		return lato*4;
	}
	public int Area() {
		return lato*lato;
	}
}
