package it.esercizioDropBox5;

public class DropBox5 {

	public static void main(String[] args) {
		// 5) Scrivere un programma Java che calcoli la somma di tutti gli elementi presenti in un array di interi.
		int arrayInt[]  = {1,2,3,4,6,24,18};

		int somma =0;
		
		for(int i = 0;i<arrayInt.length;i++) {
				somma+=arrayInt[i];
		}
		System.out.println(somma);
		
	

	}

}

