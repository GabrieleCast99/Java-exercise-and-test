package it.esercizioC;

public class esercizioC {

	public static void main(String[] args) {
		int somma=0; 
		boolean sommapari=true;
		for(int i=0; i<=300; i++) {
			if(i%2==0) {
				System.out.println("numero: "+ i);
				System.out.println("Somma: "+somma);
				somma += i;

				
			if(somma>4000 && sommapari==true) {
				sommapari=false;
				somma = somma+1;
				System.out.println("Somma dispari: "+somma);
			}	
			
				
			if(somma>6000 && somma % 2 != 0) {
				System.out.println("Somma dispari finale: "+somma);
				break;

			}
		}
		}
	}
}

