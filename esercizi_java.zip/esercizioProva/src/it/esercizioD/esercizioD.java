package it.esercizioD;

public class esercizioD {

	public static void main(String[] args) {
		String stringa= "Letto";
		Boolean doppia = false;
		
		for (int i = 0; i < stringa.length() - 1; i++) {
            char carattereCorrente = stringa.charAt(i);
            char carattereSuccessivo = stringa.charAt(i + 1);

            if (carattereCorrente == carattereSuccessivo && (carattereCorrente == 's')) {
                System.out.println("C'é una doppia S");
                doppia = true;
            } else if(carattereCorrente == carattereSuccessivo && (carattereCorrente == 'p')) {
            	System.out.println("C'é una doppia P");
            	doppia = true;
            }else if(carattereCorrente == carattereSuccessivo) {
            	System.out.println("C'é una doppia "+ carattereCorrente);
            	doppia = true;
            }
            
           
		}
		if(doppia==false) {
        	System.out.println("Nessuna doppia trovata ");
		}
		
	}
}
