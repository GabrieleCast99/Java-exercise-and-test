package it.esercizioDropBox6;

import java.util.Random;

public class DropBox6 {

	public static void main(String[] args) {
		// 6)Scrivere un programma Java che simuli il lancio di un dado a sei facce e fornisca alcune informazioni sul risultato del lancio.
        Random random = new Random();
        
        int risultato = random.nextInt(6) + 1;
        
        System.out.println("Risultato del lancio del dado: " + risultato);
        
        if (risultato % 2 == 0) {
            System.out.println("Il numero è pari");
        } else {
            System.out.println("Il numero è dispari");
        }
        
        if (risultato >= 4) {
            System.out.println("Il numero è alto");
        } else {
            System.out.println("Il numero è basso");
        }
    }
}

