package it.esercizioDropBox3;

public class DropBox3 {

	public static void main(String[] args) {
		// 3)Scrivere un programma Java che generi una password casuale di lunghezza 20 caratteri creando il metodo generaPasswordCasuale(). 
		//Si consiglia l’utilizzo di Math.Random
		String passwordCasuale = generaPasswordCasuale(20);
        System.out.println("La Password casuale é: " + passwordCasuale);
    }

    public static String generaPasswordCasuale(int lunghezza) {
        String caratteriValidi = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789";

        StringBuilder password = new StringBuilder();

        for (int i = 0; i < lunghezza; i++) {
            int indiceCasuale = (int) (Math.random() * caratteriValidi.length());

            password.append(caratteriValidi.charAt(indiceCasuale));
        }

        return password.toString();
    }
}


