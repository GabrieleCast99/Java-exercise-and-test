package it.esercizioB;

public class esercizioB {

	public static void main(String[] args) {
		int somma = 0;
		int count = 0;
		
		for(int i=1; i<=1000; i++) {
			if(i%3==0 && i%5==0) {
				System.out.println(i);
				somma +=i;
				count++;
            }

            if (count == 5) {
                break;
            
			}
		}
		System.out.println("La somma totale é "+somma);
	}

}
