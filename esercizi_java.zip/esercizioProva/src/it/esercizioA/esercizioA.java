package it.esercizioA;

import java.util.Scanner;

public class esercizioA {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
		System.out.println("digitare un numero");
		int numero= scanner.nextInt();
		
		String numeroLettere;
		
		switch(numero) {
		case 0:
			numeroLettere="ZERO";
			break;
		case 1:
			numeroLettere="UNO";
			break;
		case 2:
			numeroLettere="DUE";
			break;
		case 3:
			numeroLettere="TRE";
			break;
		case 4:
			numeroLettere="QUATTRO";
			break;
		case 5:
			numeroLettere="CINQUE";
			break;
		case 6:
			numeroLettere="SEI";
			break;
		case 7:
			numeroLettere="SETTE";
			break;	
		case 8:
			numeroLettere="OTTE";
			break;
		case 9:
			numeroLettere="NOVE";
			break;
		default:
			numeroLettere="OTHER";
			break;	
		}
		scanner.close();
		System.out.println("Il numero: "+numero+" in lettere é "+numeroLettere);
	}

}
