package it.esercizioDropBox1;

import java.util.Scanner;

public class DropBox1 {

	public static void main(String[] args) {
		// 1)Scrivere un programma Java che chiede all’utente di inserire 
		//due stringhe e che visualizza all’utente true se le stringhe sono uguali e false se sono diverse

		Scanner scanner= new Scanner(System.in);
		
		String stringa1= scanner.nextLine();
		String stringa2= scanner.nextLine();

		if (stringa1.equals(stringa2)) {
			System.out.println(true);
		}else 
			System.out.println(false);
		
		scanner.close();
	}

}
