package it.esercizioProva;

public class esercizio {

	public static void main(String[] args) {
		int a = 5;
		int b = 3;
		double r1 = (double) a/b;
		System.out.println(r1);
		
		
		char c ='a';
		short s = 5000;
		
		int r2 =c*s;
		System.out.println(r2);

		
		int i = 6;
		float f= 3.14F;
		float r3=i+f;
		System.out.println(r3);
		
		
		float r4= (float) r1-r2-r3;
		System.out.println(r4);
		
		
		byte b2 = 56;
		short s2 = 5000;
		int i2 = 10;
		
		
		
		
		
		
		
		
	
		
		
		long l = 50000L + (10L*b2)+(10L*s2)+(10L*i2);
		System.out.println(l);

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		double libbre=2;
		double kg = libbre * 0.45359237 ;
		System.out.println(kg);




	}

}
