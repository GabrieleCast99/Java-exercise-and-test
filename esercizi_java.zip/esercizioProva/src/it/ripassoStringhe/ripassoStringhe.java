package it.ripassoStringhe;

public class ripassoStringhe {

	public static void main(String[] args) {
		
		
		String s = "bottiglia", c="";
		for (int i=0;i<s.length();i++) {
			if (s.charAt(i)=='a'||s.charAt(i)=='b')
				c=c+s.charAt(i);
		}
		System.out.println(c);
	}

}
