package it.esercizioDropBox2;

import java.util.Scanner;

public class DropBox2 {

	public static void main(String[] args) {
		// 2)Scrivere un programma  in Java che fa inserire all’utente una frase f ed una stringa s, 
		//e che visualizza all’utente true se s è una sottostringa di f e false altrimenti. 
		//Il programma deve inoltre visualizzare all’utente una frase equivalente ad f ma in cui tutte le lettere sono in maiuscolo.

	Scanner scanner= new Scanner(System.in);
		
		String frase1= scanner.nextLine();
		String stringa2= scanner.nextLine();

		if (frase1.contains(stringa2)) {
			System.out.println(true);
		}else 
			System.out.println(false);
		
		System.out.println(frase1.toUpperCase());
		scanner.close();
	}
	

}
