package it.esercizioE;

public class esercizioE {

	public static void main(String[] args) {
		String stringa= "tassa";
		
		for (int i = 0; i < stringa.length(); i++) {
			char carattereCorrente = stringa.charAt(i);

    	for (int j = i + 1; j < stringa.length(); j++) {
    		char carattereSuccessivo = stringa.charAt(j);

    		if (carattereCorrente == carattereSuccessivo) {
    			System.out.println(carattereCorrente + "" + carattereSuccessivo);
    			}
			}   
		}
	}
}
