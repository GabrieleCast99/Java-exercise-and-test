package it.esercizioDropBox4;

public class DropBox4 {

	public static void main(String[] args) {
		// 4) Scrivere un programma Java che trovi il valore massimo presente in un array di interi.
		//Si assuma inizialmente che il primo elemento dell’array sia il massimo iniziale
		
		int arrayInt[]  = {1,2,3,4,6,24,18};

		int a =0;
		
		for(int i = 0;i<arrayInt.length;i++) {
			if(arrayInt[i]>a) {
				a=arrayInt[i];
			}
		}
		System.out.println(a);
		
	}

}
