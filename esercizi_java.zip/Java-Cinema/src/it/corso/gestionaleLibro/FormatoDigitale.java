package it.corso.gestionaleLibro;

public interface FormatoDigitale {
	
	void visualizza();

}
