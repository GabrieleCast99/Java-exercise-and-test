package esercizioFilm;
/*
 * Una videoteca può essere caratterizzata tramite il nome, l
’
indirizzo, il nome del proprietario e
l
’
elenco dei film in dvd che possono
essere noleggiati. Scrivere una classe
Videoteca, il cui costruttore imposta il numero massimo di film in dvd che possono
essere gestiti. Oltre ai metodi che restituiscono i valori delle variabili istanza, definire
i seguenti metodi:
-
un metodo che aggiunge un film in dvd nell’elenco dei dvd di una videoteca;
-
un metodo che restituisce true se, dato un film f, esiste nella videoteca il dvd di f,
altrimenti il metodo restituisce false;
-
un metodo che restituisce l
’
elenco dei titoli dei film in dvd
disponibili in una videoteca
 */
public class Videoteca {

	private String nome;
	private String indirizzo;
	private String proprietario;
	private FilmDVD[] elencoDvd;
    private int numFilmDVD;

	
	
	public Videoteca(String nome, String indirizzo, String proprietario, int numMaxFilmDVD) {
        this.nome = nome;
        this.indirizzo = indirizzo;
        this.proprietario = proprietario;
        this.elencoDvd = new FilmDVD[numMaxFilmDVD];
        this.numFilmDVD = 0;
    }
	
	public void aggiuntaDvd(FilmDVD filmdvd) {
		if(elencoDvd.length>numFilmDVD) {
			elencoDvd[numFilmDVD]=filmdvd;
			numFilmDVD++;
		}
	}
	
	public boolean checkElenco(FilmDVD film) {
		for(int i=0;i<elencoDvd.length;i++) {
			if(elencoDvd[i].equals(film)) {
				return true;
			}
		}
		return false;
	}
	
	public void stampaNomi() {
		for(int i=0;i<elencoDvd.length;i++) {
			System.out.println(elencoDvd[i].getTitolo());
		}
	}
	
	
}
