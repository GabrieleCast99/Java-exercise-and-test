package esercizioFilm;
/*
 * NUM 1
Un film può essere caratterizzato dal titolo, il nome del regista, la lingua originale,
l’anno e la nazione di produzione. Scrivere una classe Film con gli opportuni costruttori
ed i metodi che restituiscono i valori delle variabili istanza.
Inoltre, definire un metodo
per modificare il titolo di un film ed un metodo che restituisce una stringa che descrive
un film.
 */
public class Film {
	
	private String titolo;
	private String nomeRegista;
	private String linguaOriginale;
	private int year;
	private String nazione;
	
	
	public Film(String titolo, String nomeRegista, String linguaOriginale, int year, String nazione) {
		this.titolo = titolo;
		this.nomeRegista = nomeRegista;
		this.linguaOriginale = linguaOriginale;
		this.year = year;
		this.nazione = nazione;
	}


	public String getTitolo() {
		return titolo;
	}


	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}


	public String getNomeRegista() {
		return nomeRegista;
	}


	public void setNomeRegista(String nomeRegista) {
		this.nomeRegista = nomeRegista;
	}


	public String getLinguaOriginale() {
		return linguaOriginale;
	}


	public void setLinguaOriginale(String linguaOriginale) {
		this.linguaOriginale = linguaOriginale;
	}


	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}


	public String getNazione() {
		return nazione;
	}


	public void setNazione(String nazione) {
		this.nazione = nazione;
	}


	public String infoFilm() {
		return "Film [titolo=" + titolo + ", nomeRegista=" + nomeRegista + ", linguaOriginale=" + linguaOriginale
				+ ", year=" + year + ", nazione=" + nazione + "]";
	}
	
	

}
