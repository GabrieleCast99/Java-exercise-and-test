package esercizioFilm;

public class Main {

	public static void main(String[] args) {
			
		Film film = new Film("La vita è bella","Roberto Benigni","Italiano",1997,"Italia");
		
		//film.setTitolo("La vita é piú bella");
		
		
		
		String[] lingueSottotitoli = new String[4];
		String[] lingueAudio=new String[4];
		FilmDVD film2 = new FilmDVD("La vita è bella","Roberto Benigni","Italiano",1997,"Italia");
		
		film2.aggiungiAudio("Italiano");
		
		film2.aggiungiAudio("Inglese");
		
		film2.aggiungiSottotitoli("Italiano");


		
		System.out.println(film2);
		
		
		
		film2.check(film);
		
	}
}
