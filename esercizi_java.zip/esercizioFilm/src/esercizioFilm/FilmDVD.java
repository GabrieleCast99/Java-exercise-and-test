package esercizioFilm;

import java.util.Arrays;

public class FilmDVD extends Film {
	
	private String[] lingueAudio;
	private String[] lingueSottotitoli;
	private int numeroLingueAudio;
	private int numeroLingueSottotitoli;


	

	public FilmDVD(String titolo, String nomeRegista, String linguaOriginale, int year, String nazione) {
		super(titolo, nomeRegista, linguaOriginale, year, nazione);
		this.lingueAudio=new String[4];
		this.lingueSottotitoli=new String[4];
		this.numeroLingueAudio = 0;
		this.numeroLingueAudio= 0;
	}



	public String[] getLingueAudio() {
		return lingueAudio;
	}



	public void setLingueAudio(String[] lingueAudio) {
		this.lingueAudio = lingueAudio;
	}



	public String[] getLingueSottotitoli() {
		return lingueSottotitoli;
	}



	public void setLingueSottotitoli(String[] lingueSottotitoli) {
		this.lingueSottotitoli = lingueSottotitoli;
	}

	public void aggiungiAudio(String s) {
			lingueAudio[numeroLingueAudio]=s;
			numeroLingueAudio++;
	}
	
	public void aggiungiSottotitoli(String s) {
		lingueSottotitoli[numeroLingueSottotitoli]=s;
		numeroLingueSottotitoli++;
	}


	public boolean check(Film film) {
		if(film.getTitolo().equals(this.getTitolo())) {
			System.out.println("i titoli sono uguali");
			return true;
		}
		
		System.out.println("i titoli sono diversi");
		return false;
	}
	
	
	
	
	@Override
	public String toString() {
		return "FilmDVD Titolo "+ getTitolo() + " [lingueAudio=" + Arrays.toString(lingueAudio) + ", lingueSottotitoli="
				+ Arrays.toString(lingueSottotitoli) + "]";
	}
	
	
	
	
	
}
