package it.GestioneUniveritá;

import java.util.ArrayList;
import java.util.List;

/**
 * La classe Studente rappresenta uno studente all'interno di un'Università.
 */
public class Studente {

	/** Il nome dello studente. */
	private String name;
	
	/** Il cognome dello studente. */
	private String cognome;
	
	/** L'identificatore univoco dello studente. */
	private int IdUnivoco;
	
	/** L'anno di iscrizione dello studente. */
	private int anno;
	
	/** La lista dei corsi a cui lo studente è iscritto. */
	private List<Corso> corsiIscritto;
	
	/**
	 * Costruttore della classe Studente.
	 *
	 * @param name il nome dello studente
	 * @param cognome il cognome dello studente
	 * @param idUnivoco l'identificatore univoco dello studente
	 * @param anno l'anno di iscrizione dello studente
	 */
	public Studente(String name, String cognome, int idUnivoco, int anno) {
		this.name = name;
		this.cognome = cognome;
		IdUnivoco = idUnivoco;
		this.anno = anno;
		this.corsiIscritto = new ArrayList<>();
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getCognome() {
		return cognome;
	}



	public void setCognome(String cognome) {
		this.cognome = cognome;
	}



	public int getIdUnivoco() {
		return IdUnivoco;
	}



	public void setIdUnivoco(int idUnivoco) {
		IdUnivoco = idUnivoco;
	}



	public int getAnno() {
		return anno;
	}



	public void setAnno(int anno) {
		this.anno = anno;
	}



	public List<Corso> getCorsiIscritto() {
		return corsiIscritto;
	}



	public void setCorsiIscritto(List<Corso> corsiIscritto) {
		this.corsiIscritto = corsiIscritto;
	}



	@Override
	public String toString() {
		return "\nStudente [name=" + name + ", cognome=" + cognome + ", IdUnivoco=" + IdUnivoco + ", anno=" + anno
				+ ",  corsiIscritto=" + corsiIscritto + "]";
	}
	
	
	/**
	 * Aggiunge uno studente a un corso.
	 *
	 * @param corso il corso a cui aggiungere lo studente
	 * @param codiceId il codice identificativo del corso
	 */
	 public void aggiungiStudenteCorso(Corso corso, int codiceId) {
		 if(corso.getIdUnivoco() == codiceId) {
			 	corsiIscritto.add(corso);
			 	corso.aggiuntaStudente(this);
		 }
	    }
	 
	 /**
	  * Rimuove uno studente da un corso.
	  *
	  * @param corso il corso da cui rimuovere lo studente
	  * @param codiceId il codice identificativo del corso
	  */
	 public void rimozioneStudenteCorso(Corso corso, int codiceId) {
		 if(corso.getIdUnivoco() == codiceId) {
			 	corsiIscritto.remove(corso);
			 	corso.rimozioneStudente(this, codiceId);
		 }
	    } 
	
	 
	 
	 
	 
}
