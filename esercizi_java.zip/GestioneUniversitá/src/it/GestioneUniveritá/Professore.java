package it.GestioneUniveritá;

import java.util.ArrayList;
import java.util.List;

/**
 * La classe Professore rappresenta un docente all'interno di un'Università.
 */
public class Professore {

	/** Il nome del professore. */
	private String name;
	
	/** Il cognome del professore. */
	private String cognome;
	
	/** L'identificatore univoco del professore. */
	private int IdUnivoco;
	
	/** La lista dei corsi insegnati dal professore. */
	private List<Corso> corsiInsegnamento;
	
	/**
	 * Costruttore della classe Professore.
	 *
	 * @param name il nome del professore
	 * @param cognome il cognome del professore
	 * @param idUnivoco l'identificatore univoco del professore
	 */
	public Professore(String name, String cognome, int idUnivoco) {
		this.name = name;
		this.cognome = cognome;
		IdUnivoco = idUnivoco;
		this.corsiInsegnamento = new ArrayList<>();
	}




	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public String getCognome() {
		return cognome;
	}





	public void setCognome(String cognome) {
		this.cognome = cognome;
	}





	public int getIdUnivoco() {
		return IdUnivoco;
	}





	public void setIdUnivoco(int idUnivoco) {
		IdUnivoco = idUnivoco;
	}





	public List<Corso> getCorsiInsegnamento() {
		return corsiInsegnamento;
	}





	public void setCorsiInsegnamento(List<Corso> corsiInsegnamento) {
		this.corsiInsegnamento = corsiInsegnamento;
	}





	@Override
	public String toString() {
		return "\nProfessore [name=" + name + ", cognome=" + cognome + ", IdUnivoco=" + IdUnivoco + ", corsiInsegnamento="
				+ corsiInsegnamento + "]";
	}
	

	/**
	 * Aggiunge un corso alla lista dei corsi insegnati dal professore.
	 *
	 * @param corso il corso da aggiungere alla lista dei corsi insegnati
	 * @param codiceId il codice identificativo del corso
	 */
	public void aggiuntaCorso(Corso corso, int codiceId) {
		if(corso.getIdUnivoco() == codiceId) {
			corsiInsegnamento.add(corso);
			corso.setProfTitolare(this);
		}
	}
	
	/**
	 * Rimuove un corso dalla lista dei corsi insegnati dal professore.
	 *
	 * @param corso il corso da rimuovere dalla lista dei corsi insegnati
	 * @param codiceId il codice identificativo del corso
	 */
	public void rimozioneCorso(Corso corso, int codiceId) {
		if(corso.getIdUnivoco() == codiceId) {
			corsiInsegnamento.remove(corso);
			corso.setProfTitolare(null);
		}
	}
	
	
}
