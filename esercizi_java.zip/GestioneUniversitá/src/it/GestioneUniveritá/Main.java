package it.GestioneUniveritá;

public class Main {

	public static void main(String[] args) {
		Universitá universitá=new Universitá();

		Studente studente1= new Studente("viola","viola",5078,2022);
		Studente studente2= new Studente("Luigi","Verdi",4567,2022);
		Studente studente3= new Studente("verde","Verdi",7865,2022);

		

		universitá.creazioneStudente(studente1, 5078);
		universitá.creazioneStudente(studente2, 4567);
		universitá.creazioneStudente(studente3, 7865);


		
		Professore professore1= new Professore("Blu","Blues",8902);
		Professore professore2= new Professore("Giallo","Yellow",9784);
		
		
		
		universitá.creazioneProfessore(professore1, 8902);
		universitá.creazioneProfessore(professore2, 9784);


		
		Corso corso1= new Corso("Programmazione Java",8435,null,30);
		corso1.setProfTitolare(professore1);
		universitá.assegnazioneProfessore(professore1, corso1, 8435);
		
		universitá.creaCorso(corso1, 8435);
		
		universitá.iscrizioneStudente(studente1, corso1);
		universitá.iscrizioneStudente(studente3, corso1);
		studente2.aggiungiStudenteCorso(corso1, 8435);


		
		//System.out.println(universitá.listaStudenti());
		System.out.println(universitá.listaProfessore());

	}

}
