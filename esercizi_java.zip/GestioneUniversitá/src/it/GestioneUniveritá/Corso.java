package it.GestioneUniveritá;

import java.util.ArrayList;
import java.util.List;

/**
 * La classe Corso rappresenta un corso all'interno di un'Università.
 */
public class Corso {
	
	/** Il titolo del corso. */
	private String TitoloCorso;
	
	/** L'identificatore univoco del corso. */
	private int IdUnivoco;
	
	/** Il professore titolare del corso. */
	private Professore profTitolare;
	
	/** La lista degli studenti iscritti al corso. */
	private List<Studente> studentiIscritti;
	
	/** Il numero massimo di studenti che possono iscriversi al corso. */
	private int maxStudenti;
	
	/**
	 * Costruttore della classe Corso.
	 *
	 * @param titoloCorso il titolo del corso
	 * @param idUnivoco l'identificatore univoco del corso
	 * @param profTitolare il professore titolare del corso
	 * @param maxStudenti il numero massimo di studenti che possono iscriversi al corso
	 */
	public Corso(String titoloCorso, int idUnivoco, Professore profTitolare, int maxStudenti) {
		this.TitoloCorso = titoloCorso;
		this.IdUnivoco = idUnivoco;
		this.profTitolare = profTitolare;
		this.studentiIscritti = new ArrayList<>();
		this.maxStudenti = maxStudenti;
	}



	public String getTitoloCorso() {
		return TitoloCorso;
	}



	public void setTitoloCorso(String titoloCorso) {
		TitoloCorso = titoloCorso;
	}



	public int getIdUnivoco() {
		return IdUnivoco;
	}



	public void setIdUnivoco(int idUnivoco) {
		IdUnivoco = idUnivoco;
	}



	public Professore getProfTitolare() {
		return profTitolare;
	}


	//
	public void setProfTitolare(Professore profTitolare) {
		this.profTitolare = profTitolare;
	}



	public List<Studente> getStudentiIscritti() {
		return studentiIscritti;
	}



	public void setStudentiIscritti(List<Studente> studentiIscritti) {
		this.studentiIscritti = studentiIscritti;
	}



	public int getMaxStudenti() {
		return maxStudenti;
	}



	public void setMaxStudenti(int maxStudenti) {
		this.maxStudenti = maxStudenti;
	}



	@Override
	public String toString() {
		return "Corso [TitoloCorso=" + TitoloCorso + ", IdUnivoco=" + IdUnivoco + ", profTitolare=" + profTitolare
				+ ", studentiIscritti=" + studentiIscritti + ", maxStudenti=" + maxStudenti + "]";
	}
	
	/**
	 * Aggiunge uno studente alla lista degli studenti iscritti al corso se non è stato raggiunto il numero massimo di iscritti.
	 *
	 * @param studente lo studente da aggiungere al corso
	 * @return true se lo studente è stato aggiunto con successo, altrimenti false
	 */
	public boolean aggiuntaStudente(Studente studente) {
		if(studentiIscritti.size() < maxStudenti) {
			studentiIscritti.add(studente);
			return true;
		}
		return false;
	}
	
	
	
	/**
	 * Rimuove uno studente dalla lista degli studenti iscritti al corso.
	 *
	 * @param studente lo studente da rimuovere dal corso
	 * @param codice l'identificatore univoco dello studente
	 */
	public void rimozioneStudente(Studente studente, int codice) {
		if(studente.getIdUnivoco() == codice) {
			studentiIscritti.remove(studente);
		}
	}
	

}
