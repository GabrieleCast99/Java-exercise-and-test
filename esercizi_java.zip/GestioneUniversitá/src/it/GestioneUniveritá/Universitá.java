package it.GestioneUniveritá;

import java.util.ArrayList;
import java.util.List;

/**
 * La classe Universitá rappresenta un'istituzione universitaria.
 */
public class Universitá {
	
	/** La lista degli studenti iscritti all'università. */
	private List<Studente> listaStudenti;
	
	/** La lista dei professori dell'università. */
	private List<Professore> listaProfessore;
	
	/** La lista dei corsi offerti dall'università. */
	private List<Corso> listaCorso;
	
	
	/**
	 * Costruttore della classe Universitá.
	 */
	public Universitá() {
		this.listaStudenti = new ArrayList<>();
		this.listaProfessore = new ArrayList<>();
		this.listaCorso = new ArrayList<>();
	}
	
	


	public List<Studente> getListaStudenti() {
		return listaStudenti;
	}


	public void setListaStudenti(List<Studente> listaStudenti) {
		this.listaStudenti = listaStudenti;
	}


	public List<Professore> getListaProfessore() {
		return listaProfessore;
	}


	public void setListaProfessore(List<Professore> listaProfessore) {
		this.listaProfessore = listaProfessore;
	}


	public List<Corso> getListaCorso() {
		return listaCorso;
	}


	public void setListaCorso(List<Corso> listaCorso) {
		this.listaCorso = listaCorso;
	}


	@Override
	public String toString() {
		return "Universitá [listaStudenti=" + listaStudenti + ", listaProfessore=" + listaProfessore + ", listaCorso="
				+ listaCorso + "]";
	}

	
	/**
	 * Crea uno studente e lo aggiunge alla lista degli studenti dell'università.
	 *
	 * @param studente lo studente da creare e aggiungere
	 * @param codiceId il codice identificativo dello studente
	 */
	public void creazioneStudente(Studente studente, int codiceId) {
		if(studente.getIdUnivoco() == codiceId) {
			listaStudenti.add(studente);
		}
	}
	
	/**
	 * Crea un professore e lo aggiunge alla lista dei professori dell'università.
	 *
	 * @param professore il professore da creare e aggiungere
	 * @param codiceId il codice identificativo del professore
	 */
	public void creazioneProfessore(Professore professore, int codiceId) {
		if(professore.getIdUnivoco() == codiceId) {
			listaProfessore.add(professore);
		}
		
	}
	
	/**
	 * Crea un corso e lo aggiunge alla lista dei corsi offerti dall'università.
	 *
	 * @param corso il corso da creare e aggiungere
	 * @param codiceId il codice identificativo del corso
	 */
	public void creaCorso(Corso corso, int codiceId) {
		if(corso.getIdUnivoco() == codiceId) {
	        listaCorso.add(corso);
		}
    }
	
	/**
	 * Iscrive uno studente a un corso se ci sono ancora posti disponibili.
	 *
	 * @param studente lo studente da iscrivere al corso
	 * @param corso il corso a cui iscrivere lo studente
	 */
	public void iscrizioneStudente(Studente studente, Corso corso) {
		if(corso.getStudentiIscritti().size() < corso.getMaxStudenti()) {
			corso.aggiuntaStudente(studente);
		} else {
            System.out.println("Errore: Il corso " + corso.getTitoloCorso() + " ha raggiunto il numero massimo di studenti.");
		}
	}
	
	/**
	 * Assegna un professore come titolare di un corso.
	 *
	 * @param professore il professore da assegnare come titolare del corso
	 * @param corso il corso al quale assegnare il professore come titolare
	 * @param codiceId il codice identificativo del professore
	 */
	public void assegnazioneProfessore(Professore professore, Corso corso, int codiceId) {
		if(professore.getIdUnivoco() == codiceId) {
			corso.setProfTitolare(professore);
		}
	}
	
	/**
	 * Restituisce la lista degli studenti iscritti all'università.
	 *
	 * @return la lista degli studenti iscritti all'università
	 */
	public List<Studente> listaStudenti() {
		return listaStudenti;
	}
	public List<Professore> listaProfessore() {
		return listaProfessore;
	}
}
