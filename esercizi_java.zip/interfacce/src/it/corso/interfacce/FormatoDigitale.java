package it.corso.interfacce;

public interface FormatoDigitale {
	
	public void visualizza();

}
