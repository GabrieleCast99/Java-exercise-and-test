package it.corso.interfacce;

public class LibroCartaceco extends Libro {
	
	
	
	
	
	
	@Override
	public String informazioni() {
		return "Libro [titolo=" + getTitolo() + ", autore=" + getAutore() + ", numeroPagine=" + getNumeroPagine() + "]";
	}



	public LibroCartaceco(String titolo, String autore, int numeroPagine) {
		super(titolo, autore, numeroPagine);
	}
	
	
	
	
}
