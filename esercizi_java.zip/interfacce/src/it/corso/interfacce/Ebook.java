package it.corso.interfacce;

public class Ebook extends Libro implements FormatoDigitale{

	@Override
	public String informazioni() {
		return "Libro [titolo=" + getTitolo() + ", autore=" + getAutore() + ", numeroPagine=" + getNumeroPagine() + "]";
	}

	public Ebook(String titolo, String autore, int numeroPagine) {
		super(titolo, autore, numeroPagine);
	}
	
	@Override
	public void visualizza() {
		System.out.println("Questo libro é disponibile in digitale");
	}

}
