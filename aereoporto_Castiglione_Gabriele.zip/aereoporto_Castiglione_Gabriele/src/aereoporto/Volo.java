package aereoporto;

import java.util.Arrays;

public class Volo  {

	private String sigla;
	private Aereoporto aereoPartenza;
	private Aereoporto aereoDestinazione;
	private String aereomobile;
	private Passeggero[] elencoPasseggeri;
	
	private int maxPosti;
	private int countPosti;
	
	public Volo(String sigla, Aereoporto aereoPartenza, Aereoporto aereoDestinazione,
			String aereomobile, Passeggero[] elencoPasseggeri, int maxPosti, int countPosti) {
		this.sigla=sigla;
		this.aereoPartenza = aereoPartenza;
		this.aereoDestinazione = aereoDestinazione;
		this.aereomobile = aereomobile;
		this.elencoPasseggeri = new Passeggero[maxPosti];
		this.maxPosti = maxPosti;
		this.countPosti = 0;
	}

	public boolean aggiuntaPasseggero(Passeggero passeggero) {
		if(maxPosti>countPosti) {
			elencoPasseggeri[countPosti++] = passeggero;
			System.out.println("Passeggero aggiunto, posti occupati: "+countPosti);
			return true;
		}
		return false;  
	}
	
	public String descrizioneVolo(Volo volo) {
		return "Volo "+this.sigla+" "+aereoPartenza.getCitta()+" "+this.aereoPartenza+" "+aereoDestinazione.getCitta()+" "+this.aereoDestinazione;
	}
	

	public void elencoNomi(Volo volo) {
		for(int i=0;i<countPosti;i++) {
			System.out.println(elencoPasseggeri[i].getNome());
		}
	}
	
	public void elencoPostiVegetariani(Volo volo) {
		for(int i=0;i<countPosti;i++) {
			if(elencoPasseggeri[i].getTipoPasto().equals("vegetariano")) {
				System.out.println(elencoPasseggeri[i].getPosto());
			}else
				System.out.println("Nessuna persona vegetariana presente");
		}
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public Aereoporto getAereoPartenza() {
		return aereoPartenza;
	}

	public void setAereoPartenza(Aereoporto aereoPartenza) {
		this.aereoPartenza = aereoPartenza;
	}

	public Aereoporto getAereoDestinazione() {
		return aereoDestinazione;
	}

	public void setAereoDestinazione(Aereoporto aereoDestinazione) {
		this.aereoDestinazione = aereoDestinazione;
	}

	public String getAereomobile() {
		return aereomobile;
	}

	public void setAereomobile(String aereomobile) {
		this.aereomobile = aereomobile;
	}

	public Passeggero[] getElencoPasseggeri() {
		return elencoPasseggeri;
	}

	public void setElencoPasseggeri(Passeggero[] elencoPasseggeri) {
		this.elencoPasseggeri = elencoPasseggeri;
	}

	public int getMaxPosti() {
		return maxPosti;
	}

	public void setMaxPosti(int maxPosti) {
		this.maxPosti = maxPosti;
	}

	public int getCountPosti() {
		return countPosti;
	}

	public void setCountPosti(int countPosti) {
		this.countPosti = countPosti;
	}

	@Override
	public String toString() {
		return "Volo [sigla=" + sigla + ", aereoPartenza=" + aereoPartenza + ", aereoDestinazione=" + aereoDestinazione
				+ ", aereomobile=" + aereomobile + ", elencoPasseggeri=" + Arrays.toString(elencoPasseggeri)
				+ ", maxPosti=" + maxPosti + ", countPosti=" + countPosti + "]";
	}

	
	
	
	
}
