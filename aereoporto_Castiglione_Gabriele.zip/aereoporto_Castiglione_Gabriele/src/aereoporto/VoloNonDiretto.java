package aereoporto;

import java.util.Arrays;

public class VoloNonDiretto extends Volo {
	
	private Aereoporto[] scali;
	private int cont;
	
	
	
	public VoloNonDiretto(String sigla, Aereoporto aereoPartenza,
			Aereoporto aereoDestinazione, String aereomobile, Passeggero[] elencoPasseggeri, int maxPosti,
			int countPosti, Aereoporto[] scali, int cont) {
		super(sigla, aereoPartenza, aereoDestinazione, aereomobile, elencoPasseggeri, maxPosti,
				countPosti);
		this.scali = new Aereoporto[4];
		this.cont = cont;
	}

	
	
	public void aggiuntaScalo(Aereoporto aereoporto) {
		if(scali.length>cont) {
			scali[cont++]=aereoporto;
			System.out.println("Scalo aggiunto");
		}
	}
	
	public String descrizioneVoloScali(Volo volo) {
		StringBuilder  descrizione = new StringBuilder("Volo "+getSigla()+" "+getAereoPartenza().getCitta()+" "+getAereoPartenza()+" "+getAereoDestinazione().getCitta()+" "+getAereoDestinazione()+" --- ");
		if (scali.length > 0) {
			descrizione.append(" Questo volo avrá i seguenti scali: ");
	        for (Aereoporto scalo : scali) {
	            descrizione.append(scalo.getCitta()).append(" ").append(scalo.getNome()).append("  ");
	        }
	        
		}
		return descrizione.toString();
	}



	public Aereoporto[] getScali() {
		return scali;
	}



	public void setScali(Aereoporto[] scali) {
		this.scali = scali;
	}



	public int getCont() {
		return cont;
	}



	public void setCont(int cont) {
		this.cont = cont;
	}



	@Override
	public String toString() {
		return "VoloNonDiretto [scali=" + Arrays.toString(scali) + ", cont=" + cont + "]";
	}
	
	
	
	

	

}
