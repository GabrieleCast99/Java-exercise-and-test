package aereoporto;

public class VoloTest {

	public static void main(String[] args) {

		Aereoporto aereoporto = new Aereoporto("Fiumicino", "Roma", "FCO");
		Aereoporto aereoporto2 = new Aereoporto("Barcellona", "Barcellona", "BCL");

		

		Passeggero passeggero = new Passeggero("Mario Rossi", "Italiana", "AZ124", "16F", "vegetariano");
		Passeggero passeggero2 = new Passeggero("Luigi Verdi", "Italiana", "AZ124", "16F", "vegetariano");
		passeggero.setPostoPasseggero("17F", "Mario Rossi");

		

		Aereoporto aereoportoPartenza = new Aereoporto("Fiumicino", "Roma", "FCO");
		Aereoporto aereoportoDestinazione = new Aereoporto("Heathrow", "Londra", "LHR");
		
		

		Passeggero[] passeggeri = new Passeggero[2];
		passeggeri[0] = passeggero;
		
		
		

		Volo volo = new Volo("AZ124", aereoportoPartenza, aereoportoDestinazione, "Airbus300", passeggeri, 100, 1);
		volo.aggiuntaPasseggero(passeggero);
		System.out.println(volo.descrizioneVolo(volo));
		volo.aggiuntaPasseggero(passeggero2);
		volo.elencoNomi(volo);
		volo.elencoPostiVegetariani(volo);
		
		

		Aereoporto[] scali = {aereoporto2};
		VoloNonDiretto volonondiretto = new VoloNonDiretto("BA202",aereoporto, aereoporto, "Boeing777", passeggeri, 200, 2, scali, 0);
		
		volonondiretto.setScali(scali);
		
		
		System.out.println(volonondiretto.descrizioneVoloScali(volonondiretto));
		
		

	}

}
