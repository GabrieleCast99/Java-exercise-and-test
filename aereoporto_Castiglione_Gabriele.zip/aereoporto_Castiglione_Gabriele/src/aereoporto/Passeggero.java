package aereoporto;

public class Passeggero {
	
	private String nome;
	private String nazionalita;
	private String siglaVolo;
	private String posto;
	private String tipoPasto;
	
	
	public Passeggero(String nome, String nazionalita, String siglaVolo, String posto, String tipoPasto) {
		this.nome = nome;
		this.nazionalita = nazionalita;
		this.siglaVolo = siglaVolo;
		this.posto = posto;
		this.tipoPasto = tipoPasto;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getNazionalita() {
		return nazionalita;
	}


	public void setNazionalita(String nazionalita) {
		this.nazionalita = nazionalita;
	}


	public String getSiglaVolo() {
		return siglaVolo;
	}


	public void setSiglaVolo(String siglaVolo) {
		this.siglaVolo = siglaVolo;
	}


	public String getPosto() {
		return posto;
	}


	public void setPosto(String posto) {
		this.posto = posto;
	}


	public String getTipoPasto() {
		return tipoPasto;
	}


	public void setTipoPasto(String tipoPasto) {
		this.tipoPasto = tipoPasto;
	}
	
	
	public void setPostoPasseggero(String posto,String nome) {
		if(this.nome.equals(nome)) {
			this.posto = posto;
		}
	}


	@Override
	public String toString() {
		return "Passeggero [nome=" + nome + ", nazionalita=" + nazionalita + ", siglaVolo=" + siglaVolo + ", posto="
				+ posto + ", tipoPasto=" + tipoPasto + "]";
	}
	
	
	
	
}

