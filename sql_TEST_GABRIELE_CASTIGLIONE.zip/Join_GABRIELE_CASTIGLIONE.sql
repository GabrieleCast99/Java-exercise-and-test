-- scrivere una query per trovare nome e cognome  dei dipendenti che lavorano a londra ed estrarre il reparto
SELECT employees.FIRST_NAME,employees.LAST_NAME,employees.JOB_ID,employees.DEPARTMENT_ID,departments.DEPARTMENT_NAME
FROM employees
INNER JOIN departments ON employees.DEPARTMENT_ID=departments.DEPARTMENT_ID
WHERE departments.LOCATION_ID = 2400;


-- trovare id dipendente , cognome, insieme al manager id e cognome
SELECT e.employee_id AS id_dipendente,e.last_name AS cognome_dipendente,e.manager_id AS id_manager,m.last_name AS cognome_manager
FROM employees e
INNER JOIN employees m ON e.manager_id = m.employee_id;


-- visualizzare nome , cognome, data di assunzione, stipendio del manager per tutti i manager con esperienza superiore a 15 anni
SELECT FIRST_NAME,LAST_NAME,HIRE_DATE,SALARY
FROM employees
INNER JOIN departments ON employees.MANAGER_ID=departments.MANAGER_ID
WHERE DATEDIFF(CURDATE(), HIRE_DATE) > 15 * 365;

-- trovare gli indirizzi di tutti i dipartimenti 
SELECT DEPARTMENT_NAME,locations.LOCATION_ID,STREET_ADDRESS,CITY,STATE_PROVINCE,countries.COUNTRY_NAME
FROM departments
INNER JOIN locations ON departments.LOCATION_ID=locations.LOCATION_ID
INNER JOIN countries ON locations.COUNTRY_ID=countries.COUNTRY_ID;

-- visualizzare la cronologia del lavoro che é stata eseguita da qualsiasi dipendenti che abbia come stipendio piú di 10k
SELECT job_history.EMPLOYEE_ID,START_DATE,END_DATE,job_history.JOB_ID,job_history.DEPARTMENT_ID,SALARY
FROM job_history
INNER JOIN employees ON job_history.EMPLOYEE_ID=employees.EMPLOYEE_ID
WHERE SALARY>10000;