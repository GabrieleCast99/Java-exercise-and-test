CREATE TABLE ruolo (
    ID_G INT PRIMARY KEY AUTO_INCREMENT,
    TIPOLOGIA ENUM('Admin', 'Utente', 'Docente')
);

CREATE TABLE utente (
    ID_U INT PRIMARY KEY AUTO_INCREMENT,
    Nome VARCHAR(255),
    Cognome VARCHAR(255),
    email VARCHAR(255),
    password VARCHAR(255)
);

CREATE TABLE utente_ruolo (
    FK_U INT,
    FK_G INT,
    FOREIGN KEY (FK_U) REFERENCES utente(ID_U),
    FOREIGN KEY (FK_G) REFERENCES ruolo(ID_G)
);

CREATE TABLE categoria (
    ID_CA INT PRIMARY KEY AUTO_INCREMENT,
	Nome_Categoria ENUM('FrontEnd', 'BackEnd', 'FullStack', 'Cybersecurity')
);

CREATE TABLE corso (
    ID_C INT PRIMARY KEY AUTO_INCREMENT,
    Nome_Corso VARCHAR(255),
    Descrizione_breve VARCHAR(255),
    Descrizione_completa TEXT,
    Durata INT,
    FK_CA INT,
    FOREIGN KEY (FK_CA) REFERENCES categoria(ID_CA)
);

CREATE TABLE utenti_corsi (
    FK_UC INT,
    FK_CU INT,
    FOREIGN KEY (FK_UC) REFERENCES utente(ID_U),
    FOREIGN KEY (FK_CU) REFERENCES corso(ID_C)
);